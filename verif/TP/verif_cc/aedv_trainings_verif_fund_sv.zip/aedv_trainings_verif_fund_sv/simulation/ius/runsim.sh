#!/bin/env sh

#tclsh env.tcl
wish sim.tcl

