#!/bin/env sh

vsim -do sim.do

