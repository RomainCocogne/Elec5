UART16550 APB Wrapper
=====================
